import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  CheckCircle2, 
  ArrowRight, 
  Phone, 
  Mail, 
  MapPin, 
  Instagram, 
  ChevronDown,
  Plus,
  MessageSquare,
  Send,
  ExternalLink,
  Target,
  Zap,
  ShieldCheck,
  Smartphone,
  Search,
  Code2,
  Layout,
  Rocket
} from "lucide-react";
import { ImagePlaceholder, LogoImage } from "./MainSections";

// --- Mission & Story Section ---
export const MissionAndStory = () => {
  return (
    <div className="space-y-40 py-32 bg-white">
      {/* Mission */}
      <section className="container mx-auto px-6 grid lg:grid-cols-2 gap-24 items-center">
        <motion.div 
          className="order-2 lg:order-1"
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1, ease: "easeOut" }}
        >
          <span className="text-primary-dark font-black tracking-[0.4em] uppercase text-xs mb-8 block">Filosofi Studio</span>
          <h2 className="text-5xl md:text-[5.5rem] font-display font-black leading-[0.9] mb-12 tracking-tighter text-slate-900">
            Estetika <br /> <span className="text-slate-200">Yang Berjiwa.</span>
          </h2>
          <div className="space-y-8 text-slate-500 text-lg leading-relaxed font-medium mb-16">
            <p>
              Di DjayaStudio, kami tidak percaya pada template. Setiap proyek adalah kanvas kosong yang kami isi dengan strategi visual yang unik dan teknologi terdepan.
            </p>
            <p>
              Misi kami sederhana: Menghapus batasan antara ide kreatif Anda dan realitas digital yang fungsional. Kami bekerja dengan hati untuk hasil yang berarti.
            </p>
          </div>
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="btn-primary group py-5 px-10"
          >
            Filosofi Kami <ArrowRight className="inline-block ml-3 w-5 h-5 group-hover:translate-x-2 transition-transform" />
          </motion.button>
        </motion.div>
        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
          className="order-1 lg:order-2"
        >
          <ImagePlaceholder label="Artistic Craft" aspect="aspect-[4/3]" />
        </motion.div>
      </section>

      {/* Story */}
      <section className="container mx-auto px-6 grid lg:grid-cols-2 gap-24 items-center">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
        >
          <ImagePlaceholder label="Digital Evolution" aspect="aspect-[4/3]" />
        </motion.div>
        <motion.div
          initial={{ opacity: 0, x: 50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1, ease: "easeOut" }}
        >
          <span className="text-primary-dark font-black tracking-[0.4em] uppercase text-xs mb-8 block">Evolusi Brand</span>
          <h2 className="text-5xl md:text-[5.5rem] font-display font-black leading-[0.9] mb-12 tracking-tighter text-slate-900">
            Tumbuh <br /> <span className="text-slate-200">Lebih Kencang.</span>
          </h2>
          <div className="space-y-8 text-slate-500 text-lg leading-relaxed font-medium mb-16">
            <p>
              Website adalah wajah masa depan bisnis Anda. Kami memastikan wajah itu tidak hanya cantik, tapi juga memiliki integritas performa yang tak tertandingi di industri.
            </p>
            <p>
              Bersama Djaya, Anda tidak hanya mendapatkan website. Anda mendapatkan ekosistem pertumbuhan yang siap menghadapi dinamika pasar yang terus berubah.
            </p>
          </div>
          <motion.button 
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="btn-outline group py-5 px-10"
          >
            Jadwal Diskusi <ArrowRight className="inline-block ml-3 w-5 h-5 group-hover:translate-x-2 transition-transform" />
          </motion.button>
        </motion.div>
      </section>
    </div>
  );
};

// --- Our Values Section ---
export const OurValues = () => {
  const values = [
    { title: "Transparan", desc: "Komunikasi terbuka tanpa ada biaya tersembunyi atau janji manis kosong." },
    { title: "Cepat & Tepat", desc: "Eksekusi kilat dengan akurasi tinggi untuk mengejar momentum bisnis Anda." },
    { title: "Berani Beda", desc: "Desain yang menonjol agar brand Anda mudah diingat di tengah persaingan ketat." },
    { title: "Bertanggung Jawab", desc: "Kami mengawal website Anda hingga benar-benar siap dan berjalan lancar." },
    { title: "Sinergi Kreatif", desc: "Memadukan ide Anda dengan keahlian teknis kami untuk hasil optimal." },
    { title: "Fokus Solusi", desc: "Kami tidak hanya membangun website, kami membantu menyelesaikan masalah bisnis Anda." }
  ];

  return (
    <section className="py-32 bg-slate-50">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-24 items-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <span className="text-primary-dark font-black tracking-[0.4em] uppercase text-xs mb-8 block">Nilai Utama Kami</span>
            <h2 className="text-5xl md:text-8xl font-display font-black leading-[0.9] mb-10 tracking-tighter text-slate-900">Prinsip <br /> Kerja Djaya.</h2>
            <p className="text-slate-500 text-lg leading-relaxed mb-16 max-w-lg font-medium">
              Landasan yang membuat setiap proyek di DjayaStudio memiliki kualitas internasional yang bisa diandalkan.
            </p>
            <div className="bg-white p-6 rounded-3xl inline-flex items-center gap-4 text-slate-900 font-black uppercase tracking-widest text-[10px] border border-slate-200 shadow-sm">
               <div className="w-10 h-10 rounded-full bg-primary-dark flex items-center justify-center text-white"><Phone className="w-4 h-4" /></div>
               Obrolan Santai, Hubungi Kami!
            </div>
          </motion.div>
          
          <div className="grid sm:grid-cols-2 gap-8">
            {values.map((val, index) => (
              <motion.div 
                key={index}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1, duration: 0.8, ease: "easeOut" }}
                whileHover={{ y: -10, scale: 1.02 }}
                className="p-10 bg-white border border-slate-100 rounded-[2.5rem] transition-all duration-500 hover:border-primary shadow-sm hover:shadow-xl hover:shadow-primary/5"
              >
                <div className="w-14 h-14 bg-primary/20 rounded-2xl flex items-center justify-center mb-6 border border-primary">
                  <CheckCircle2 className="w-6 h-6 text-primary-dark" />
                </div>
                <h3 className="text-xl font-display font-black mb-4 tracking-tight text-slate-900">{val.title}</h3>
                <p className="text-[10px] text-slate-400 leading-relaxed font-bold tracking-wider uppercase">{val.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

// --- Why Choose Us Component ---
export const WhyChooseUs = () => {
  const reasons = [
    { title: "Maintenance Gratis", desc: "Kami bantu pantau website kamu selama 3 bulan pertama secara cuma-cuma." },
    { title: "Teknologi Terbaru", desc: "Selalu menggunakan framework modern yang menjamin kecepatan dan keamanan." },
    { title: "UI/UX Artistik", desc: "Desain yang tidak hanya fungsional tapi juga memiliki nilai seni yang tinggi." },
    { title: "Harga Start-up", desc: "Penawaran harga yang sangat bersahabat untuk bisnis yang baru merintis." },
    { title: "Sangat SEO Friendly", desc: "Struktur koding yang rapi agar website kamu cepat mejeng di halaman 1." },
    { title: "Support Fast Respon", desc: "Butuh bantuan mendesak? Tim kami siap merespon pertanyaan kamu dengan cepat." }
  ];

  return (
    <section className="py-32 bg-white relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row items-end justify-between gap-12 mb-24">
          <motion.div 
            className="max-w-3xl"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1, ease: "easeOut" }}
          >
            <span className="text-primary-dark font-black tracking-[0.4em] uppercase text-xs mb-8 block">Alasan Utama</span>
            <h2 className="text-5xl md:text-8xl font-display font-black leading-tight tracking-tighter text-slate-900">Mengapa Memilih <br /> Creative Djaya?</h2>
          </motion.div>
          <button className="btn-primary py-5 px-12">Mulai Perjalanan</button>
        </div>

        <div className="grid md:grid-cols-3 gap-12">
          {reasons.map((item, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              className="group"
            >
              <div className="flex items-center gap-4 mb-6">
                <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center group-hover:bg-primary transition-all duration-500 shadow-lg shadow-primary/20 border border-primary">
                  <CheckCircle2 className="w-4 h-4 text-primary-dark group-hover:text-white transition-colors" />
                </div>
                <h3 className="text-xl font-display font-black text-slate-900 tracking-tight">{item.title}</h3>
              </div>
              <p className="text-slate-500 font-medium leading-relaxed border-l-2 border-slate-200 pl-6 transition-all group-hover:border-primary">
                {item.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// --- Process Section ---
export const Process = () => {
  const steps = [
    { 
      number: "01", 
      title: "Diskusi & Strategi", 
      desc: "Kita ngobrol santai bahas kebutuhan bisnis kamu dan tentukan target audiens." 
    },
    { 
      number: "02", 
      title: "Desain & Build", 
      desc: "Tim desainer dan developer kami mulai meracik website impianmu secepat kilat." 
    },
    { 
      number: "03", 
      title: "Launch & Growth", 
      desc: "Website resmi mengudara dan siap menyambut pelanggan baru untuk bisnis kamu." 
    }
  ];

  return (
    <section className="py-40 bg-slate-900 relative overflow-hidden">
      <div className="absolute top-0 right-0 p-40 opacity-5 rotate-12"><Rocket className="w-96 h-96 text-white" /></div>
      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-24">
          <span className="text-primary font-black tracking-[0.4em] uppercase text-xs mb-8 block">Alur Kerja</span>
          <h2 className="text-5xl md:text-8xl font-display font-black leading-tight tracking-tighter text-white">Proses Kerja <br /> Yang Simpel.</h2>
        </div>

        <div className="grid md:grid-cols-3 gap-12">
          {steps.map((step, idx) => (
            <motion.div 
              key={idx} 
              className="relative group"
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.2, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            >
               <div className="text-[10rem] font-display font-black text-white/5 leading-none absolute -top-20 left-0 transition-all duration-700 group-hover:text-primary/20 group-hover:-translate-x-10 group-hover:rotate-12 select-none">{step.number}</div>
               <div className="relative z-10 pt-10">
                 <h3 className="text-3xl font-display font-black mb-8 tracking-tight text-white">{step.title}</h3>
                 <p className="text-slate-400 text-lg leading-relaxed font-bold tracking-wider uppercase border-t border-white/10 pt-10 group-hover:text-white transition-colors duration-700">{step.desc}</p>
               </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// --- CTA Section ---
export const CTA = () => {
  return (
    <section className="py-24 px-6 bg-white">
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
        className="container mx-auto bg-slate-900 rounded-[4rem] p-16 md:p-32 text-center text-white relative overflow-hidden group shadow-2xl"
      >
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(190,242,100,0.1)_0%,transparent_70%)] animate-pulse"></div>
        
        <div className="relative z-10">
          <motion.span 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-[10px] font-black tracking-[0.5em] uppercase mb-10 block text-primary font-black"
          >
            Siap Untuk Sukses?
          </motion.span>
          <motion.h2 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.4, duration: 1 }}
            className="text-5xl md:text-[7rem] font-display font-black leading-[0.85] mb-12 tracking-tighter"
          >
             Bikin Website <br /> Kamu Sekarang.
          </motion.h2>
          <motion.p 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ delay: 0.6, duration: 1 }}
            className="text-slate-400 max-w-2xl mx-auto text-xl font-medium mb-16 px-4"
          >
             Tingkatkan level bisnis Anda dengan website profesional yang didesain khusus untuk menarik pelanggan.
          </motion.p>
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.8 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-8"
          >
            <button className="btn-primary bg-primary text-slate-900 hover:bg-white hover:text-slate-900 px-12 py-5 rounded-3xl font-black text-xs tracking-widest uppercase transition-all duration-500 shadow-2xl">Mulai Sekarang</button>
            <button className="px-12 py-5 border-2 border-slate-700 hover:border-primary text-slate-400 hover:text-primary rounded-3xl font-black text-xs tracking-widest uppercase transition-all duration-500">Tanya Harganya</button>
          </motion.div>
        </div>
      </motion.div>
    </section>
  );
};

// --- FAQ Section ---
export const FAQ = () => {
  const [openIdx, setOpenIdx] = useState<number | null>(0);
  
  const faqs = [
    { q: "Berapa lama website saya jadi?", a: "Untuk paket standar, website kamu sudah bisa online dalam 5 sampai 7 hari kerja saja." },
    { q: "Saya belum punya konten, gimana?", a: "Tenang, tim kami bisa bantu carikan gambar pendukung and bantu rapikan tulisan kamu." },
    { q: "Apakah ada biaya bulanan?", a: "Tidak ada biaya bulanan ke kami. Kamu cuma perlu perpanjang domain and hosting setahun sekali." },
    { q: "Bisa ganti foto sendiri?", a: "Tentu! Kami pake sistem yang gampang banget digunain buat kamu ganti-ganti foto and teks sendiri." },
    { q: "Apa websitenya dapet domain .com?", a: "Iya, semua paket kami sudah termasuk gratis domain .com atau .my.id untuk tahun pertama." }
  ];

  return (
    <section className="py-32 bg-slate-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-24">
          <span className="text-primary-dark font-black tracking-[0.4em] uppercase text-xs mb-8 block">Bantuan Cepat</span>
          <h2 className="text-5xl md:text-8xl font-display font-black tracking-tighter text-slate-900">Yang Sering <br /> <span className="text-slate-300">Ditanyain</span></h2>
        </div>

        <div className="max-w-4xl mx-auto space-y-4">
          {faqs.map((faq, idx) => (
            <motion.div 
              key={idx} 
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1, duration: 0.8 }}
              className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-sm"
            >
               <button 
                onClick={() => setOpenIdx(openIdx === idx ? null : idx)}
                className="w-full p-8 flex items-center justify-between text-left hover:bg-slate-50 transition-colors"
               >
                 <span className="text-xl font-display font-black tracking-tight text-slate-900">{faq.q}</span>
                 <ChevronDown className={`w-6 h-6 transition-transform duration-500 ${openIdx === idx ? 'rotate-180 text-primary-dark' : 'text-slate-300'}`} />
               </button>
               <AnimatePresence>
                 {openIdx === idx && (
                   <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden"
                   >
                     <div className="p-8 pt-0 text-slate-500 font-medium leading-relaxed border-t border-slate-100 bg-slate-50/50">
                        {faq.a}
                     </div>
                   </motion.div>
                 )}
               </AnimatePresence>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

// --- Footer Section ---
export const Footer = () => {
  return (
    <footer className="pt-32 pb-12 bg-white border-t border-slate-100">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-3 gap-20 items-start mb-32">
          {/* Brand Info */}
          <div className="space-y-10">
            <div className="flex items-center group cursor-pointer">
              <LogoImage className="h-16" />
            </div>
            <p className="text-slate-500 text-lg font-medium leading-relaxed">
              Partner terpercaya UMKM Indonesia dalam membangun identitas digital yang profesional and modern.
            </p>
            <div className="flex items-center gap-6">
              {[Instagram].map((Icon, idx) => (
                <a key={idx} href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center hover:bg-primary-dark hover:text-white transition-all duration-500 hover:scale-110">
                  <Icon className="w-6 h-6" />
                </a>
              ))}
            </div>
          </div>

          <div className="lg:col-span-2 grid md:grid-cols-2 gap-10">
             <div className="bg-primary p-12 rounded-[3.5rem] text-slate-900 group hover:bg-slate-900 hover:text-white transition-all duration-700 shadow-xl shadow-primary/10">
                <div className="flex items-center gap-6 mb-10">
                   <div className="w-16 h-16 bg-slate-900 text-white rounded-2xl flex items-center justify-center group-hover:bg-primary group-hover:text-slate-900 transition-colors"><Phone className="w-8 h-8" /></div>
                   <div>
                      <p className="text-[10px] font-black tracking-widest uppercase mb-1 opacity-70">Hubungi Kami</p>
                      <p className="text-2xl font-display font-black leading-none tracking-tight">(+62) 838 3798 6267</p>
                   </div>
                </div>
                <button className="flex items-center gap-3 font-black text-xs uppercase tracking-[0.2em] group-hover:gap-5 transition-all">WHATSAPP KAMI <ArrowRight className="w-6 h-6" /></button>
             </div>

             <div className="bg-slate-50 p-12 rounded-[3.5rem] text-slate-900 group hover:bg-slate-100 transition-all duration-700 border border-slate-200">
                <div className="flex items-center gap-6 mb-10">
                   <div className="w-16 h-16 bg-white text-slate-900 border border-slate-200 rounded-2xl flex items-center justify-center"><Mail className="w-8 h-8" /></div>
                   <div>
                      <p className="text-[10px] font-black tracking-widest uppercase mb-1 opacity-70">Email Resmi</p>
                      <p className="text-2xl font-display font-black leading-none tracking-tight">admin@djaya.studio</p>
                   </div>
                </div>
                <button className="flex items-center gap-3 font-black text-xs uppercase tracking-[0.2em] group-hover:gap-5 transition-all">KIRIM EMAIL <ArrowRight className="w-6 h-6" /></button>
             </div>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-12 pt-20 border-t border-slate-100 mb-16">
          <FooterLinks title="Alamat" links={["Bekasi, Jawa Barat", "Indonesia"]} isText />
          <FooterLinks title="Jelajahi" links={["Home", "About", "Services", "Contact"]} />
          <FooterLinks title="Legal" links={["Kebijakan Privasi", "Ketentuan Layanan"]} />
          <FooterLinks title="Social" links={["Instagram", "WhatsApp"]} />
        </div>

        <div className="text-center pt-8 border-t border-slate-100 text-[10px] font-black tracking-[0.3em] uppercase text-slate-300">
          © 2026 DJAYASTUDIO. SELALU MEMBERIKAN YANG TERBAIK.
        </div>
      </div>
    </footer>
  );
};

const FooterLinks = ({ title, links, isText = false }: { title: string; links: string[]; isText?: boolean }) => (
  <div className="space-y-8">
    <h4 className="text-slate-900 font-display font-black text-xs uppercase tracking-[0.3em]">{title}</h4>
    <div className="space-y-4">
      {links.map((link, idx) => (
        isText ? (
          <p key={idx} className="text-slate-400 text-sm font-medium leading-relaxed">{link}</p>
        ) : (
          <a key={idx} href="#" className="block text-slate-400 hover:text-primary-dark hover:translate-x-2 transition-all font-medium text-sm">{link}</a>
        )
      ))}
    </div>
  </div>
);

// --- Blog Section ---
export interface BlogPostData {
  id: string;
  title: string;
  excerpt: string;
  content: string;
  date: string;
  category: string;
  image: string;
  author: string;
}

export const blogPosts: BlogPostData[] = [
  {
    id: "umkm-digital-2026",
    title: "Revolusi Digital UMKM: Mengapa Website Adalah Kunci di 2026",
    excerpt: "Di tahun 2026, media sosial saja tidak cukup. Pelajari mengapa website profesional dari DjayaStudio menjadi pembeda utama.",
    content: `
      <p>Pasar digital Indonesia telah berubah secara drastis. Jika sepuluh tahun lalu memiliki website dianggap sebagai "kemewahan", di tahun 2026 ini, website adalah fondasi utama kepercayaan konsumen.</p>
      
      <h3>1. Kontrol Penuh Atas Brand Anda</h3>
      <p>Berbeda dengan media sosial yang algoritmanya selalu berubah, website memberikan Anda kendali penuh atas bagaimana brand Anda ditampilkan. Anda tidak perlu khawatir jangkauan Anda dibatasi oleh algoritma pihak ketiga.</p>
      
      <h3>2. Optimasi Mesin Pencari (SEO)</h3>
      <p>Mayoritas konsumen memulai pencarian produk mereka melalui Google. Dengan website yang dioptimasi dengan baik oleh DjayaStudio, bisnis Anda akan muncul di baris terdepan saat calon pelanggan mencari solusi yang Anda tawarkan.</p>
      
      <h3>3. Integrasi Pembayaran Otomatis</h3>
      <p>Website modern memungkinkan Anda menerima pesanan 24/7 tanpa harus membalas chat satu per satu. Ini adalah efisiensi yang dibutuhkan UMKM untuk tumbuh lebih cepat.</p>
    `,
    date: "Mei 10, 2026",
    category: "Strategi Bisnis",
    image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800",
    author: "Tim Redaksi Djaya"
  },
  {
    id: "desain-minimalis-2026",
    title: "Psikologi Desain Minimalis: Mengapa 'Kurang' Lebih Baik Untuk Konversi",
    excerpt: "Memahami mengapa desain bersih dan minimalis dari DjayaStudio justru lebih efektif dalam meningkatkan konversi penjualan Anda.",
    content: `
      <p>Seringkali, pemilik bisnis ingin memasukkan semua informasi ke dalam satu halaman. Namun, data menunjukkan bahwa kesederhanaan justru membuahkan hasil yang lebih baik.</p>
      
      <h3>Fokus Pada Pesan Utama</h3>
      <p>Dengan desain yang bersih, mata pengunjung langsung tertuju pada tombol aksi (CTA) yang paling penting. Kami di DjayaStudio menggunakan whitespace secara strategis untuk mengurangi beban kognitif pengunjung.</p>
      
      <h3>Kecepatan Adalah Segalanya</h3>
      <p>Desain minimalis bukan hanya soal estetika, tapi juga soal performa. Halaman yang ringan akan dimuat lebih cepat, dan kecepatan adalah faktor nomor satu yang menentukan apakah pengunjung tetap bertahan di situs Anda atau pergi.</p>
    `,
    date: "Mei 08, 2026",
    category: "Design Tips",
    image: "https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&q=80&w=800",
    author: "Creative Djaya"
  },
  {
    id: "keamanan-web-umkm",
    title: "Menjaga Keamanan Data Pelanggan UMKM: Aman Bersama Djaya",
    excerpt: "Keamanan data bukan lagi pilihan. Simak langkah-langkah DjayaStudio dalam memastikan website bisnis Anda aman dari serangan siber.",
    content: `
      <p>Kepercayaan pelanggan adalah aset nomor satu. Sekali data mereka bocor, reputasi bisnis Anda bisa hancur seketika.</p>
      
      <h3>Standar SSL Tingkat Lanjut</h3>
      <p>Semua website yang kami bangun dilengkapi dengan enkripsi SSL tingkat lanjut. Ini memastikan komunikasi antara browser pelanggan dan server Anda terenkripsi sepenuhnya.</p>
      
      <h3>Perlindungan Dari Serangan Umum</h3>
      <p>Kami menerapkan firewall dan lapisan keamanan tambahan untuk melindungi website Anda dari serangan brute force, SQL injection, dan ancaman umum lainnya yang sering mengincar situs bisnis.</p>
    `,
    date: "Mei 05, 2026",
    category: "Teknologi",
    image: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?auto=format&fit=crop&q=80&w=800",
    author: "Dev Team Djaya"
  }
];

export const Blog = ({ onPostClick }: { onPostClick?: (post: BlogPostData) => void }) => {
  const [displayedPosts, setDisplayedPosts] = useState(3);

  return (
    <section id="blog" className="py-40 bg-slate-50">
      <div className="container mx-auto px-6 text-center mb-24">
        <span className="text-primary-dark font-black tracking-[0.4em] uppercase text-xs mb-8 block">Wawasan Digital</span>
        <h2 className="text-5xl md:text-8xl font-display font-black tracking-tighter text-slate-900">Blog & Update <br /> <span className="text-slate-300">Terbaru Kami.</span></h2>
      </div>
      
      <div className="container mx-auto px-6 grid md:grid-cols-3 gap-12">
        {blogPosts.slice(0, displayedPosts).map((post, index) => (
          <motion.article 
            key={post.id}
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            whileHover={{ y: -15 }}
            className="bg-white rounded-[3rem] border border-slate-200 overflow-hidden group shadow-sm hover:shadow-2xl hover:shadow-primary/10 transition-all duration-500"
          >
            <div className="aspect-video overflow-hidden relative">
              <img src={post.image} alt={post.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-1000" />
              <div className="absolute top-6 left-6 bg-primary text-slate-900 px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest">{post.category}</div>
            </div>
            <div className="p-10 text-left">
              <div className="flex items-center gap-4 text-[10px] font-black uppercase tracking-widest text-primary-dark mb-6">
                <div className="w-2 h-2 rounded-full bg-primary animate-ping"></div>
                {post.date}
              </div>
              <h3 className="text-2xl font-display font-black mb-6 tracking-tight text-slate-900 group-hover:text-primary-dark transition-colors">{post.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed font-medium mb-10 line-clamp-3">{post.excerpt}</p>
              <button 
                onClick={() => onPostClick?.(post)}
                className="flex items-center gap-3 font-black text-[10px] uppercase tracking-widest text-slate-900 hover:gap-5 transition-all"
              >
                Baca Selengkapnya <ArrowRight className="w-4 h-4 text-primary-dark" />
              </button>
            </div>
          </motion.article>
        ))}
      </div>
      
      {displayedPosts < blogPosts.length && (
        <div className="text-center mt-24">
          <button 
            onClick={() => setDisplayedPosts(prev => prev + 3)}
            className="btn-outline px-12 group"
          >
            Lihat Update Lainnya <Plus className="inline-block ml-3 w-5 h-5 group-hover:rotate-90 transition-transform" />
          </button>
        </div>
      )}
    </section>
  );
};

// --- Pricing Section ---
export const Pricing = () => {
  const plans = [
    { 
      title: "Paket Starter", 
      price: "1.230 JT", 
      bg: "bg-white", 
      features: [
        "1 Halaman Website", 
        "Desain Modern & Responsive", 
        "Tombol WhatsApp Otomatis", 
        "Integrasi Google Maps", 
        "Form Kontak", 
        "Optimasi Mobile", 
        "Basic SEO Google", 
        "Keamanan SSL HTTPS", 
        "Revisi 2x", 
        "Gratis Upload Website"
      ],
      benefits: [
        "Bisnis lebih profesional",
        "Mudah masuk Google",
        "Tingkatkan kepercayaan",
        "Siap untuk promosi/iklan"
      ]
    },
    { 
      title: "Paket Business", 
      price: "2.400 JT", 
      bg: "bg-slate-900 text-white", 
      popular: true, 
      features: [
        "Hingga 5 Halaman", 
        "Desain Premium", 
        "Animasi Modern", 
        "Form Booking / Pemesanan", 
        "Galeri Foto & Video", 
        "Integrasi WhatsApp & Sosmed", 
        "SEO Optimized", 
        "Admin Dashboard Sederhana", 
        "Kecepatan Website Optimal", 
        "Revisi 4x"
      ],
      benefits: [
        "Branding lebih kuat",
        "Website cepat & nyaman",
        "Bisa terima order langsung",
        "Meningkatkan value bisnis"
      ]
    },
    { 
      title: "Paket Professional", 
      price: "4.507 JT", 
      bg: "bg-white", 
      features: [
        "Hingga 10 Halaman", 
        "Custom UI/UX Premium", 
        "Dashboard Admin Lengkap", 
        "Sistem Artikel / Blog", 
        "Sistem Testimoni", 
        "Integrasi Email Bisnis", 
        "Live Chat WhatsApp", 
        "Optimasi SEO Advanced", 
        "Optimasi Speed Website", 
        "Revisi Unlimited"
      ],
      benefits: [
        "Tampil seperti korporat",
        "Lebih dipercaya customer",
        "Meningkatkan penjualan",
        "Siap Google & Meta Ads"
      ]
    },
    { 
      title: "Paket Corporate Elite", 
      price: "5.576 JT", 
      bg: "bg-primary", 
      features: [
        "Website Full Custom", 
        "Unlimited Halaman", 
        "Sistem Multi Admin", 
        "Integrasi Pembayaran", 
        "Sistem Booking / Reservasi", 
        "Dashboard Profesional", 
        "SEO Premium", 
        "Integrasi Google Analytics", 
        "Backup Otomatis", 
        "Sistem Keamanan Premium"
      ],
      benefits: [
        "Eksklusif & Elit",
        "Sistem website lengkap",
        "Scale-up jangka panjang",
        "Branding perusahaan besar"
      ]
    },
    { 
      title: "Paket Ultimate Enterprise", 
      price: "8.700 JT", 
      bg: "bg-white", 
      features: [
        "Website Premium Full Custom", 
        "Sistem Sesuai Request", 
        "UI/UX Eksklusif & Modern", 
        "Fitur Login Member", 
        "Marketplace / E-Commerce", 
        "Sistem Booking Lengkap", 
        "Integrasi API", 
        "Dashboard Super Admin", 
        "Multi Bahasa", 
        "SEO Expert Optimization"
      ],
      benefits: [
        "Kualitas Tertinggi (VIP)",
        "Toko Online / Marketplace",
        "Stabil & Anti Lag",
        "Citra & Kredibilitas Maksimum"
      ]
    }
  ];

  return (
    <section id="pricing" className="py-40 bg-white relative overflow-hidden">
      <div className="container mx-auto px-6">
        <div className="flex flex-col md:flex-row items-end justify-between gap-12 mb-24">
           <motion.div 
            className="max-w-3xl text-left"
            initial={{ opacity: 0, y: 50 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 1, ease: "easeOut" }}
           >
              <span className="text-primary-dark font-black tracking-[0.4em] uppercase text-xs mb-8 block">Investasi Digital</span>
              <h2 className="text-5xl md:text-8xl font-display font-black leading-tight tracking-tighter text-slate-900">Paket Jasa Pembuatan <br /> Website DJAYASTUDIO.</h2>
           </motion.div>
        </div>

        <div className="grid lg:grid-cols-2 xl:grid-cols-5 gap-6">
          {plans.map((plan, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: idx * 0.1, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ y: -20, scale: 1.02 }}
              className={`${plan.bg} p-8 rounded-[2.5rem] border border-slate-200 overflow-hidden relative group transition-all duration-700 shadow-sm hover:shadow-2xl flex flex-col`}
            >
              {plan.popular && (
                 <div className="absolute top-6 right-6 bg-primary text-slate-900 px-3 py-1 rounded-full text-[8px] font-black tracking-widest uppercase">Populer</div>
              )}
              <h4 className={`text-lg font-display font-black mb-6 tracking-tight leading-tight ${plan.bg.includes('slate-900') ? 'text-white' : 'text-slate-900'}`}>{plan.title}</h4>
              <div className="mb-8">
                <p className={`text-2xl font-display font-black tracking-tighter ${plan.bg.includes('slate-900') ? 'text-white' : 'text-slate-900'}`}>{plan.price}</p>
              </div>
              
              <div className="space-y-3 mb-8">
                <p className="text-[8px] font-black tracking-widest uppercase opacity-40 mb-4">Fitur Utama:</p>
                {plan.features.slice(0, 6).map((f, i) => (
                  <div key={i} className={`flex items-start gap-2 text-[9px] font-bold tracking-wider uppercase opacity-70 group-hover:opacity-100 transition-opacity ${plan.bg.includes('slate-900') ? 'text-slate-300' : 'text-slate-500'}`}>
                    <CheckCircle2 className="w-3 h-3 text-primary-dark mt-0.5 shrink-0" />
                    <span>{f}</span>
                  </div>
                ))}
              </div>

              <div className="space-y-3 mb-10 pt-6 border-t border-slate-100/10 flex-grow">
                <p className="text-[8px] font-black tracking-widest uppercase opacity-40 mb-4">Keunggulan:</p>
                {plan.benefits?.map((b, i) => (
                  <div key={i} className={`flex items-start gap-2 text-[9px] font-bold tracking-widest uppercase text-primary-dark`}>
                    <Zap className="w-3 h-3 text-primary mt-0.5 shrink-0 fill-primary" />
                    <span>{b}</span>
                  </div>
                ))}
              </div>

              <button className={`w-full py-4 rounded-xl font-black text-[10px] tracking-widest uppercase transition-all duration-500 ${plan.popular ? 'bg-primary text-slate-900 hover:bg-white hover:text-slate-900' : plan.bg === 'bg-primary' ? 'bg-slate-900 text-white' : 'bg-slate-900 text-white hover:bg-primary hover:text-slate-900'}`}>Mulai Sekarang</button>
            </motion.div>
          ))}
        </div>
        
        <motion.div 
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-32 p-12 bg-slate-50 rounded-[3rem] border border-slate-200 text-center"
        >
          <h3 className="text-2xl font-display font-black mb-8 text-slate-900">Semua Paket DJAYASTUDIO Mendapat:</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-5xl mx-auto">
            {["Gratis Domain 1 Thn", "Gratis Hosting 1 Thn", "Gratis SSL HTTPS", "Mobile Friendly", "Responsive Device", "Bantuan Upload", "Konsultasi Gratis", "Support Fast Response"].map((item, i) => (
              <div key={i} className="flex items-center gap-3 text-[10px] font-black uppercase tracking-widest text-slate-400">
                <CheckCircle2 className="w-4 h-4 text-primary-dark" /> {item}
              </div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};
