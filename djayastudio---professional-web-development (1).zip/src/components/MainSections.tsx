import React, { useState, useRef, useEffect } from "react";
import { motion, useInView, useSpring, useTransform, animate, AnimatePresence } from "motion/react";
import { 
  Globe, 
  ShoppingBag, 
  ShieldCheck, 
  Mail, 
  Smartphone, 
  Search, 
  BarChart3, 
  CheckCircle2,
  ChevronRight,
  Phone,
  Instagram,
  ArrowRight,
  Plus,
  Rocket,
  Users,
  Target,
  ExternalLink,
  Code2,
  Layout,
  Zap
} from "lucide-react";

// --- Utility Components ---
export const Counter = ({ value, suffix = "+" }: { value: number; suffix?: string }) => {
  const [displayValue, setDisplayValue] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, amount: 0.5 });

  useEffect(() => {
    if (isInView) {
      const controls = animate(0, value, {
        duration: 2.5,
        ease: [0.16, 1, 0.3, 1],
        onUpdate: (latest) => setDisplayValue(Math.floor(latest)),
      });
      return () => controls.stop();
    }
  }, [isInView, value]);

  return <span ref={ref}>{displayValue}{suffix}</span>;
};

export const ImagePlaceholder = ({ label, aspect = "aspect-video" }: { label: string; aspect?: string }) => {
  const [image, setImage] = useState<string | null>(null);
  
  const images = [
    "https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1547658719-da2b51169166?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1557838923-2985c318be48?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800"
  ];

  const handleAdd = () => {
    if (!image) {
      setImage(images[Math.floor(Math.random() * images.length)]);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      onClick={handleAdd}
      className={`${aspect} rounded-3xl bg-slate-100 border border-slate-200 flex flex-col items-center justify-center cursor-pointer hover:border-primary hover:bg-slate-50 transition-all duration-700 group relative overflow-hidden`}
    >
      {image ? (
        <img 
          src={image} 
          className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
          alt="Illustration"
        />
      ) : (
        <div className="flex flex-col items-center text-center p-6 text-slate-400">
          <div className="w-16 h-16 rounded-2xl bg-primary/20 flex items-center justify-center mb-4 group-hover:scale-110 group-hover:rotate-12 transition-all duration-500">
            <Plus className="w-8 h-8 text-primary-dark" />
          </div>
          <span className="font-display font-bold text-[10px] tracking-widest uppercase">{label}</span>
        </div>
      )}
    </motion.div>
  );
};

// --- Logo Component ---
export const LogoImage = ({ className = "h-12" }: { className?: string }) => {
  const [logoSrc, setLogoSrc] = useState("/logo.png");
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleLogoClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setLogoSrc(url);
    }
  };
  
  return (
    <div className="flex items-center gap-4 group">
      <div 
        onClick={handleLogoClick}
        className={`cursor-pointer overflow-hidden rounded-2xl border-2 border-primary/20 hover:border-primary transition-all duration-500 shadow-lg aspect-square flex items-center justify-center bg-slate-50 relative ${className}`}
      >
        <img 
          src={logoSrc} 
          alt="Logo" 
          onError={(e) => {
            (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1614850523296-d8c1af93d400?auto=format&fit=crop&q=80&w=400";
          }}
          className="h-full w-full object-cover group-hover:scale-110 transition-transform duration-700"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
          <Plus className="w-6 h-6 text-white" />
        </div>
        <input 
          type="file" 
          ref={fileInputRef} 
          onChange={handleFileChange} 
          accept="image/*" 
          className="hidden" 
        />
      </div>
      <div className="flex flex-col leading-none">
        <span className="font-display text-2xl font-black tracking-tighter text-slate-900">DJAYA<span className="text-primary-dark">STUDIO</span></span>
        <span className="text-[8px] font-black tracking-[0.4em] uppercase text-slate-400">Digital Identity</span>
      </div>
    </div>
  );
};

// --- Navbar Component ---
export const Navbar = ({ onPageChange }: { onPageChange: (page: string) => void }) => {
  const navItems = ["Home", "About", "Services", "Contact"];
  
  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
      className="fixed top-0 left-0 right-0 z-[100] bg-white/70 backdrop-blur-3xl border-b border-slate-100 py-4 px-6 md:px-12 flex items-center justify-between"
    >
      <div 
        className="flex items-center"
      >
        <LogoImage className="h-10 md:h-14" />
      </div>
      
      <div className="hidden md:flex items-center gap-12 text-[10px] font-black tracking-[0.3em] uppercase">
        {navItems.map((item) => (
          <a 
            key={item}
            href={`#${item.toLowerCase()}`}
            onClick={(e) => {
              e.preventDefault();
              onPageChange(item);
              window.location.hash = item.toLowerCase();
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="text-slate-400 hover:text-slate-900 transition-all duration-300 relative group"
          >
            {item}
            <span className="absolute -bottom-2 left-0 w-0 h-0.5 bg-primary-dark transition-all duration-300 group-hover:w-full"></span>
          </a>
        ))}
      </div>
      
      <button 
        onClick={() => {
          onPageChange("Contact");
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        className="btn-primary py-3 px-10 text-[10px] tracking-widest font-black uppercase"
      >
        Mulai Diskusi
      </button>
    </motion.nav>
  );
};

// --- Page Header (Breadcrumbs) ---
export const PageHeader = ({ title, breadcrumbs }: { title: string; breadcrumbs: string[] }) => {
  return (
    <section className="pt-48 pb-24 bg-gradient-to-b from-primary/30 to-dark relative overflow-hidden">
      <div className="absolute top-0 right-0 p-20 opacity-10 rotate-12 -z-10 grayscale brightness-200">
        <img 
          src="https://placehold.co/800x240/0f172a/bef264?text=DJAYASTUDIO&font=playfair-display" 
          alt="DJAYASTUDIO Background" 
          className="w-[40rem] object-contain"
        />
      </div>
      <div className="container mx-auto px-6 relative z-10 text-center">
        <motion.h1 
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          className="text-5xl md:text-9xl font-display font-black mb-12 tracking-tighter text-slate-900"
        >
          {title}
        </motion.h1>
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5, duration: 1 }}
          className="flex items-center justify-center gap-6 text-[10px] font-black tracking-[0.4em] uppercase text-slate-400"
        >
          {breadcrumbs.map((crumb, idx) => (
            <span key={idx} className="flex items-center gap-6">
              <span className={idx === breadcrumbs.length - 1 ? "text-primary-dark font-black" : "hover:text-slate-900 transition-colors cursor-pointer"}>{crumb}</span>
              {idx < breadcrumbs.length - 1 && <div className="w-1.5 h-1.5 rounded-full bg-slate-200"></div>}
            </span>
          ))}
        </motion.div>
      </div>
    </section>
  );
};

// --- Hero Component ---
export const Hero = () => {
  return (
    <section id="home" className="relative min-h-[90vh] flex flex-col items-center justify-center pt-32 pb-20 overflow-hidden bg-white">
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary/20 blur-[120px] rounded-full animate-pulse"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent/10 blur-[120px] rounded-full delay-1000 animate-pulse"></div>
      </div>

      <div className="container mx-auto px-6 text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
        >
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.8 }}
            className="inline-flex items-center gap-3 px-6 py-2 rounded-full bg-slate-100 border border-slate-200 text-slate-900 text-[10px] font-black tracking-[0.4em] uppercase mb-10"
          >
            Kembangkan Bisnis Kamu Bersama Djaya
          </motion.div>
          
          <motion.h1 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 1 }}
            className="text-6xl md:text-[9.5rem] font-display font-black leading-[0.85] mb-12 tracking-tight text-slate-900"
          >
            Loncatan <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-slate-900 via-primary-dark to-slate-900 pb-4">Digital Baru.</span>
          </motion.h1>
          
          <motion.p 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 1 }}
            className="text-slate-500 max-w-2xl mx-auto text-lg font-medium leading-relaxed mb-16"
          >
            Kami membangun website modern yang tidak hanya cantik dipandang, tapi juga sangat kencang dan mudah ditemukan di Google. Fokus kami adalah pertumbuhan bisnis Anda.
          </motion.p>
          
          <motion.div 
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.8, duration: 1 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-8"
          >
            <button className="btn-primary py-5 px-12 scale-110">Konsultasi Sekarang</button>
            <button className="btn-outline flex items-center gap-4 py-5 px-12 group">
              <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center transition-transform group-hover:rotate-90"><Plus className="w-5 h-5 text-slate-900" /></div> 
              Layanan Kami
            </button>
          </motion.div>
        </motion.div>
      </div>

      <motion.div 
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 1.2, duration: 1, ease: [0.16, 1, 0.3, 1] }}
        className="absolute inset-x-0 bottom-0 py-10 border-t border-slate-50 bg-slate-50/50 backdrop-blur-sm"
      >
         <div className="container mx-auto px-6 flex justify-center items-center gap-20">
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-300">Fast Execution</span>
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-300">Modern Stack</span>
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-300">SEO Focused</span>
         </div>
      </motion.div>
    </section>
  );
};

// --- About Component ---
export const About = () => {
  const [showMore, setShowMore] = useState(false);

  return (
    <section id="about" className="py-40 bg-white">
      <div className="container mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-24 items-center">
          <div className="space-y-8">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 1 }}
            >
              <ImagePlaceholder label="Studio Creative" aspect="aspect-[4/3]" />
            </motion.div>
            <div className="grid grid-cols-2 gap-8">
               <motion.div
                 initial={{ opacity: 0, y: 30 }}
                 whileInView={{ opacity: 1, y: 0 }}
                 viewport={{ once: true }}
                 transition={{ delay: 0.2, duration: 1 }}
               >
                 <ImagePlaceholder label="Design Process" aspect="aspect-square" />
               </motion.div>
               <motion.div
                 initial={{ opacity: 0, y: 30 }}
                 whileInView={{ opacity: 1, y: 0 }}
                 viewport={{ once: true }}
                 transition={{ delay: 0.4, duration: 1 }}
               >
                 <ImagePlaceholder label="Strategy Meeting" aspect="aspect-square" />
               </motion.div>
            </div>
          </div>

          <motion.div
             initial={{ opacity: 0, y: 50 }}
             whileInView={{ opacity: 1, y: 0 }}
             viewport={{ once: true }}
             transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
          >
            <span className="text-primary-dark font-black tracking-[0.4em] uppercase text-xs mb-8 block">Kenali Djaya</span>
            <h2 className="text-5xl md:text-8xl font-display font-black leading-tight mb-10 tracking-tighter text-slate-900">
              Transformasi <br /> Tanpa Batas.
            </h2>
            
            <div className="space-y-8 text-slate-500 text-lg leading-relaxed font-medium mb-12">
              <p>
                DjayaStudio bukan sekadar studio pembuatan website. Kami adalah inkubator ide yang membantu UMKM and startup memiliki kehadiran digital yang setara dengan korporasi besar.
              </p>
              
              <AnimatePresence>
                {showMore && (
                  <motion.div 
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    className="overflow-hidden space-y-8 border-l-4 border-primary pl-8"
                  >
                    <p>
                      Setiap baris kode yang kami tulis bertujuan untuk mempermudah calon pelanggan menemukan bisnis Anda. Fokus kami adalah pada performa, keamanan, dan kejelasan pesan.
                    </p>
                    <p>
                      Bersama Djaya, transisi digital bisnis Anda akan terasa ringan. Kami menangani semua hal teknis yang membingungkan agar Anda bisa fokus jualan.
                    </p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
            
            <motion.button 
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setShowMore(!showMore)}
              className="group flex items-center gap-6 text-slate-900 font-black uppercase tracking-widest text-xs transition-all"
            >
              <div className="w-14 h-14 rounded-2xl bg-slate-900 text-white flex items-center justify-center group-hover:bg-primary group-hover:text-slate-900 transition-all duration-700 font-black text-2xl">
                {showMore ? "−" : "+"}
              </div>
              {showMore ? "Tutup Detail" : "Mari Berkenalan"}
            </motion.button>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-12 mt-20 pt-20 border-t border-slate-100">
              {[{v: 50, l: "Partner Bisnis"}, {v: 120, l: "Ide Kreatif"}, {v: 15, l: "Expert Tim"}, {v: 100, l: "Kepuasan", s: "%"}].map((stat, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: 0.5 + (i * 0.1), duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
                >
                  <StatItem value={stat.v} label={stat.l} suffix={stat.s} />
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

const StatItem = ({ value, label, suffix = "+" }: { value: number; label: string; suffix?: string }) => (
  <div>
    <div className="text-4xl font-display font-black text-slate-900 mb-2 leading-none"><Counter value={value} suffix={suffix} /></div>
    <p className="text-[9px] text-slate-400 uppercase tracking-[0.2em] font-black">{label}</p>
  </div>
);

// --- Services Component ---
export const Services = () => {
  const services = [
    {
      icon: Code2,
      title: "Landing Page Modern",
      description: "Ciptakan kesan pertama yang tak terlupakan dengan desain minimalis dan konversi tinggi."
    },
    {
      icon: Zap,
      title: "Optimasi Kecepatan",
      description: "Website yang lambat membunuh bisnis. Kami pastikan web kamu melaju super cepat di semua perangkat."
    },
    {
      icon: Search,
      title: "SEO Friendly",
      description: "Struktur website yang 'disukai' Google agar bisnis kamu muncul di urutan teratas pencarian."
    },
    {
      icon: Layout,
      title: "Sistem Manajemen Konten",
      description: "Ganti teks atau gambar semudah mengetik di Word. Tanpa perlu paham koding sama sekali."
    },
    {
      icon: Smartphone,
      title: "Responsif Mobile",
      description: "80% pengunjung pakai HP. Kami pastikan website kamu tampil sempurna di layar kecil."
    },
    {
      icon: ShieldCheck,
      title: "Maintenance & Aman",
      description: "Tim kami siaga memastikan website kamu selalu aman, up-to-date, dan berjalan lancar 24/7."
    }
  ];

  return (
    <section id="services" className="py-40 bg-slate-50 relative">
      <div className="container mx-auto px-6">
        <div className="text-center mb-24">
          <motion.span 
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-primary-dark font-black tracking-[0.4em] uppercase text-xs mb-6 block"
          >
            Keahlian Kami
          </motion.span>
          <motion.h2 
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: 0.2 }}
            className="text-5xl md:text-8xl font-display font-black tracking-tighter text-slate-900"
          >
            Solusi Digital <br /> Tanpa Ribet.
          </motion.h2>
        </div>
        
        <div className="grid md:grid-cols-3 gap-10">
          {services.map((service, index) => (
            <motion.div 
              key={index}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
              whileHover={{ y: -10 }}
              className="card-glass group text-center"
            >
              <div className="w-20 h-20 bg-primary/20 rounded-[2.5rem] flex items-center justify-center mb-10 mx-auto border border-primary transition-all duration-700 group-hover:bg-slate-900 group-hover:border-slate-900">
                <service.icon className="w-10 h-10 text-primary-dark group-hover:text-primary transition-all duration-500" />
              </div>
              <h3 className="text-2xl font-display font-black mb-6 tracking-tight text-slate-900">{service.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed font-medium">{service.description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
