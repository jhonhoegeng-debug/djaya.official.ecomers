import { useState, useEffect, useRef } from "react";
import { Navbar, Hero, About, Services, PageHeader } from "./components/MainSections";
import { WhyChooseUs, CTA, Process, Pricing, Blog, Footer, OurValues, MissionAndStory, FAQ, blogPosts, BlogPostData } from "./components/ExtraSections";
import { motion, useScroll, useSpring, AnimatePresence } from "motion/react";
import { MessageCircle, Send, ArrowLeft, Calendar, User, Clock } from "lucide-react";

export default function App() {
  const [currentPage, setCurrentPage] = useState("Home");
  const [selectedPost, setSelectedPost] = useState<BlogPostData | null>(null);
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, {
    stiffness: 100,
    damping: 30,
    restDelta: 0.001
  });

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [currentPage]);

  useEffect(() => {
    const handlePopState = () => {
      const hash = window.location.hash.replace("#", "");
      if (hash) {
        const capitalized = hash.charAt(0).toUpperCase() + hash.slice(1);
        const validPages = ["Home", "About", "Services", "Contact", "Pricing", "Blog", "Faq"];
        if (validPages.includes(capitalized)) {
          setCurrentPage(capitalized);
        }
      } else {
        setCurrentPage("Home");
      }
    };
    window.addEventListener("popstate", handlePopState);
    handlePopState();
    return () => window.removeEventListener("popstate", handlePopState);
  }, []);

  const handlePostClick = (post: BlogPostData) => {
    setSelectedPost(post);
    setCurrentPage("BlogPost");
    window.location.hash = `blog/${post.id}`;
  };

  const renderPage = () => {
    if (currentPage === "BlogPost" && selectedPost) {
      return (
        <motion.div 
          key="blog-post" 
          initial={{ opacity: 0 }} 
          animate={{ opacity: 1 }} 
          exit={{ opacity: 0 }}
          className="pt-32 pb-40"
        >
          <div className="container mx-auto px-6 max-w-4xl">
            <button 
              onClick={() => {
                setCurrentPage("Home");
                setSelectedPost(null);
                window.location.hash = "";
              }}
              className="flex items-center gap-3 font-black text-[10px] uppercase tracking-widest text-slate-400 hover:text-slate-900 transition-all mb-12 group"
            >
              <ArrowLeft className="w-5 h-5 group-hover:-translate-x-2 transition-transform" /> Kembali ke Home
            </button>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <span className="inline-block bg-primary text-slate-900 px-6 py-2 rounded-full text-[10px] font-black uppercase tracking-widest mb-8">
                {selectedPost.category}
              </span>
              <h1 className="text-5xl md:text-7xl font-display font-black leading-tight tracking-tighter text-slate-900 mb-12">
                {selectedPost.title}
              </h1>

              <div className="flex flex-wrap items-center gap-8 mb-16 pb-16 border-b border-slate-100">
                <div className="flex items-center gap-3 text-slate-400 text-[10px] font-black uppercase tracking-widest">
                  <Calendar className="w-4 h-4" /> {selectedPost.date}
                </div>
                <div className="flex items-center gap-3 text-slate-400 text-[10px] font-black uppercase tracking-widest">
                  <User className="w-4 h-4" /> {selectedPost.author}
                </div>
                <div className="flex items-center gap-3 text-slate-400 text-[10px] font-black uppercase tracking-widest">
                  <Clock className="w-4 h-4" /> 5 Min Baca
                </div>
              </div>

              <div className="aspect-video rounded-[3rem] overflow-hidden mb-20 shadow-2xl">
                <img 
                  src={selectedPost.image} 
                  alt={selectedPost.title} 
                  className="w-full h-full object-cover"
                />
              </div>

              <div 
                className="prose prose-xl prose-slate max-w-none 
                prose-headings:font-display prose-headings:font-black prose-headings:tracking-tighter prose-headings:text-slate-900
                prose-p:text-slate-500 prose-p:font-medium prose-p:leading-relaxed
                prose-strong:text-slate-900 prose-strong:font-black"
                dangerouslySetInnerHTML={{ __html: selectedPost.content }}
              />
            </motion.div>
          </div>
        </motion.div>
      );
    }

    switch(currentPage) {
      case "About":
        return (
          <motion.div key="about" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <PageHeader title="Tentang Djaya" breadcrumbs={["Home", "About"]} />
            <About />
            <MissionAndStory />
            <OurValues />
            <WhyChooseUs />
            <CTA />
          </motion.div>
        );
      case "Services":
        return (
          <motion.div key="services" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <PageHeader title="Layanan Kami" breadcrumbs={["Home", "Services"]} />
            <Services />
            <Process />
            <Pricing />
            <FAQ />
            <CTA />
          </motion.div>
        );
      case "Contact":
        return (
           <motion.div key="contact" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
             <PageHeader title="Hubungi Kami" breadcrumbs={["Home", "Contact"]} />
             <section id="contact-form" className="py-40 container mx-auto px-6 bg-white">
                <div className="grid lg:grid-cols-2 gap-24">
                   <motion.div 
                    initial={{ opacity: 0, y: 50 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.8, ease: "easeOut" }}
                    className="card-glass h-full min-h-[500px] flex flex-col items-center justify-center p-12 overflow-hidden border-slate-200 bg-primary/10 relative"
                   >
                      <div className="absolute top-0 right-0 p-10 opacity-10 rotate-12"><MessageCircle className="w-64 h-64" /></div>
                      <div className="relative z-10 text-center">
                         <div className="w-24 h-24 bg-slate-900 text-primary rounded-3xl flex items-center justify-center mb-8 mx-auto shadow-2xl">
                            <Send className="w-10 h-10" />
                         </div>
                         <h3 className="text-3xl font-display font-black text-slate-900 mb-6 uppercase tracking-tighter">Kirim Pesan <br /> Kilat</h3>
                         <p className="text-slate-500 font-medium max-w-xs mx-auto">Kami biasanya merespons semua pertanyaan dalam waktu kurang dari 24 jam kerja.</p>
                      </div>
                   </motion.div>
                   <motion.div 
                    initial={{ opacity: 0, y: 50 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
                    className="space-y-12"
                   >
                      <div className="space-y-6">
                        <span className="text-primary-dark font-black tracking-[0.4em] uppercase text-xs block">Kontak Kami</span>
                        <h2 className="text-5xl md:text-7xl font-display font-black tracking-tighter text-slate-900">Mari Berkolaborasi.</h2>
                        <p className="text-slate-500 text-lg font-medium">Punya visi besar? Tim strategis DJAYASTUDIO siap membantu mewujudkan setiap detail fungsionalitas yang Anda butuhkan.</p>
                      </div>
                      <div className="grid gap-6">
                        <div className="grid md:grid-cols-2 gap-6">
                          <input type="text" placeholder="NAMA LENGKAP" className="bg-slate-50 border border-slate-200 rounded-2xl p-6 focus:border-primary outline-none font-black text-[10px] tracking-widest uppercase transition-all text-slate-900" />
                          <input type="email" placeholder="EMAIL BISNIS" className="bg-slate-50 border border-slate-200 rounded-2xl p-6 focus:border-primary outline-none font-black text-[10px] tracking-widest uppercase transition-all text-slate-900" />
                        </div>
                        <input type="text" placeholder="SUBJEK PROYEK" className="bg-slate-50 border border-slate-200 rounded-2xl p-6 focus:border-primary outline-none font-black text-[10px] tracking-widest uppercase transition-all text-slate-900" />
                        <textarea placeholder="CERITAKAN VISI ANDA DISINI..." className="bg-slate-50 border border-slate-200 rounded-3xl p-6 h-48 focus:border-primary outline-none font-black text-[10px] tracking-widest uppercase transition-all text-slate-900"></textarea>
                        <button className="btn-primary py-5 text-[10px] tracking-widest font-black uppercase">Kirim Pesan</button>
                      </div>
                   </motion.div>
                </div>
             </section>
             <FAQ />
             <CTA />
           </motion.div>
        );
      default:
        return (
          <motion.div key="home" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
            <Hero />
            <About />
            <Services />
            <OurValues />
            <WhyChooseUs />
            <CTA />
            <Process />
            <Pricing />
            <Blog onPostClick={handlePostClick} />
          </motion.div>
        );
    }
  };

  return (
    <div className="relative bg-white min-h-screen">
      <motion.div
        className="fixed top-0 left-0 right-0 h-1 bg-primary z-[200] origin-left"
        style={{ scaleX }}
      />

      <Navbar onPageChange={setCurrentPage} />
      
      <main className="overflow-hidden">
        <AnimatePresence mode="wait">
          {renderPage()}
        </AnimatePresence>
      </main>

      <Footer />

      {/* Floating WhatsApp */}
      <motion.a 
        href="https://wa.me/6283837986267"
        target="_blank"
        rel="noreferrer"
        initial={{ scale: 0, rotate: -45 }}
        animate={{ scale: 1, rotate: 0 }}
        whileHover={{ scale: 1.1, rotate: 12 }}
        className="fixed bottom-10 right-10 z-[150] w-16 h-16 bg-[#25D366] rounded-2xl flex items-center justify-center shadow-2xl shadow-[#25D366]/40 text-white group"
      >
        <MessageCircle className="w-8 h-8" />
        <span className="absolute right-full mr-4 bg-white text-slate-900 px-4 py-2 rounded-xl text-[10px] font-black tracking-widest uppercase opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-xl border border-slate-100">WhatsApp Us</span>
      </motion.a>
    </div>
  );
}
